

import React, { useState, useEffect } from 'react';
import { SystemDoc, SystemModule } from '../../documentation';
import { CheckIcon, CloseIcon, TrashIcon, PlusIcon } from '../icons/GenericIcons';

interface SystemDocEditorProps {
  initialData: SystemDoc;
  onSave: (data: SystemDoc) => void;
  onCancel: () => void;
}

const SystemDocEditor: React.FC<SystemDocEditorProps> = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState<SystemDoc>(initialData);

  useEffect(() => {
    setFormData(initialData);
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // FIX: Separate handlers for modules (objects) and dataEntities (strings).
  const handleModuleChange = (index: number, value: string) => {
    const newModules = [...formData.modules];
    newModules[index] = { ...newModules[index], name: value };
    setFormData({ ...formData, modules: newModules });
  };

  const handleDataEntityChange = (index: number, value: string) => {
    const newDataEntities = [...formData.dataEntities];
    newDataEntities[index] = value;
    setFormData({ ...formData, dataEntities: newDataEntities });
  };

  const addListItem = (listName: 'modules' | 'dataEntities') => {
    if (listName === 'modules') {
      const newModule: SystemModule = { id: `mod_${Date.now()}`, name: '', logic: '', checkpoints: [] };
      setFormData({ ...formData, modules: [...formData.modules, newModule] });
    } else {
      setFormData({ ...formData, dataEntities: [...formData.dataEntities, ''] });
    }
  };

  const removeListItem = (listName: 'modules' | 'dataEntities', index: number) => {
    if (listName === 'modules') {
      setFormData({ ...formData, modules: formData.modules.filter((_, i) => i !== index) });
    } else {
      setFormData({ ...formData, dataEntities: formData.dataEntities.filter((_, i) => i !== index) });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center sticky top-0 z-10">
        <h2 className="text-lg font-bold text-slate-800">Edit System Documentation</h2>
        <div className="flex space-x-2">
          <button onClick={onCancel} className="p-2 text-slate-500 hover:text-slate-700 rounded-full hover:bg-slate-200 transition-colors">
            <CloseIcon className="w-5 h-5" />
          </button>
          <button onClick={() => onSave(formData)} className="p-2 bg-blue-600 text-white hover:bg-blue-700 rounded-full shadow-md transition-colors">
            <CheckIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Title */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">System Title</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="w-full bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Description</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={4}
            className="w-full bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-y"
          />
        </div>

        {/* Modules */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Function Modules</label>
          <div className="space-y-2">
            {formData.modules.map((mod, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="text"
                  // FIX: Access name property as modules is an array of objects.
                  value={mod.name}
                  onChange={(e) => handleModuleChange(idx, e.target.value)}
                  className="flex-1 bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <button onClick={() => removeListItem('modules', idx)} className="p-2 text-red-400 hover:text-red-600">
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button onClick={() => addListItem('modules')} className="flex items-center text-blue-600 text-sm font-semibold mt-2 hover:underline">
              <PlusIcon className="w-4 h-4 mr-1" /> Add Module
            </button>
          </div>
        </div>
        
        {/* Data Entities */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Data Entities</label>
          <div className="space-y-2">
            {formData.dataEntities.map((entity, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={entity}
                  onChange={(e) => handleDataEntityChange(idx, e.target.value)}
                  className="flex-1 bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <button onClick={() => removeListItem('dataEntities', idx)} className="p-2 text-red-400 hover:text-red-600">
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button onClick={() => addListItem('dataEntities')} className="flex items-center text-blue-600 text-sm font-semibold mt-2 hover:underline">
              <PlusIcon className="w-4 h-4 mr-1" /> Add Entity
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

export default SystemDocEditor;
