import React, { useState, useEffect } from 'react';
import { PageDocumentation, SYSTEM_DOCS } from '../../documentation';
import { CheckIcon, CloseIcon, TrashIcon, PlusIcon } from '../icons/GenericIcons';

interface DocEditorProps {
  initialData: PageDocumentation;
  onSave: (data: PageDocumentation) => void;
  onCancel: () => void;
}

const DocEditor: React.FC<DocEditorProps> = ({ initialData, onSave, onCancel }) => {
  const [formData, setFormData] = useState<PageDocumentation>(initialData);

  useEffect(() => {
    setFormData(initialData);
  }, [initialData]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // --- List Handlers ---

  const handleFeatureChange = (index: number, value: string) => {
    const newFeatures = [...formData.features];
    newFeatures[index] = value;
    setFormData({ ...formData, features: newFeatures });
  };

  const addFeature = () => {
    setFormData({ ...formData, features: [...formData.features, ''] });
  };

  const removeFeature = (index: number) => {
    const newFeatures = formData.features.filter((_, i) => i !== index);
    setFormData({ ...formData, features: newFeatures });
  };

  const handleImageChange = (index: number, value: string) => {
    const newImages = [...(formData.overviewImages || [])];
    newImages[index] = value;
    setFormData({ ...formData, overviewImages: newImages });
  };

  const addImage = () => {
    setFormData({ ...formData, overviewImages: [...(formData.overviewImages || []), ''] });
  };

  const removeImage = (index: number) => {
    const newImages = (formData.overviewImages || []).filter((_, i) => i !== index);
    setFormData({ ...formData, overviewImages: newImages });
  };

  const handleBackendConfigChange = (index: number, key: 'label' | 'value', newVal: string) => {
    const newConfig = [...formData.backendConfig];
    newConfig[index] = { ...newConfig[index], [key]: newVal };
    setFormData({ ...formData, backendConfig: newConfig });
  };

  const addBackendConfig = () => {
    setFormData({ ...formData, backendConfig: [...formData.backendConfig, { label: '', value: '' }] });
  };

  const removeBackendConfig = (index: number) => {
    const newConfig = formData.backendConfig.filter((_, i) => i !== index);
    setFormData({ ...formData, backendConfig: newConfig });
  };

  const handleSystemToggle = (sysId: string) => {
    const current = formData.relatedSystems || [];
    if (current.includes(sysId)) {
      setFormData({ ...formData, relatedSystems: current.filter(id => id !== sysId) });
    } else {
      setFormData({ ...formData, relatedSystems: [...current, sysId] });
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-200 flex justify-between items-center sticky top-0 z-10">
        <h2 className="text-lg font-bold text-slate-800">Edit Documentation</h2>
        <div className="flex space-x-2">
          <button onClick={onCancel} className="p-2 text-slate-500 hover:text-slate-700 rounded-full hover:bg-slate-200 transition-colors">
            <CloseIcon className="w-5 h-5" />
          </button>
          <button onClick={() => onSave(formData)} className="p-2 bg-blue-600 text-white hover:bg-blue-700 rounded-full shadow-md transition-colors">
            <CheckIcon className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Title */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Page Title</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            className="w-full bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>

        {/* Overview */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1">Overview</label>
          <textarea
            name="overview"
            value={formData.overview}
            onChange={handleChange}
            rows={4}
            className="w-full bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-y"
          />
        </div>

        {/* Overview Images */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Overview Images (URLs)</label>
          <div className="space-y-2">
            {(formData.overviewImages || []).map((url, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={url}
                  onChange={(e) => handleImageChange(idx, e.target.value)}
                  className="flex-1 bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="https://..."
                />
                <button onClick={() => removeImage(idx)} className="p-2 text-red-400 hover:text-red-600">
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button onClick={addImage} className="flex items-center text-blue-600 text-sm font-semibold mt-2 hover:underline">
              <PlusIcon className="w-4 h-4 mr-1" /> Add Image URL
            </button>
          </div>
        </div>

        {/* Features */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Features</label>
          <div className="space-y-2">
            {formData.features.map((feat, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={feat}
                  onChange={(e) => handleFeatureChange(idx, e.target.value)}
                  className="flex-1 bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <button onClick={() => removeFeature(idx)} className="p-2 text-red-400 hover:text-red-600">
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button onClick={addFeature} className="flex items-center text-blue-600 text-sm font-semibold mt-2 hover:underline">
              <PlusIcon className="w-4 h-4 mr-1" /> Add Feature
            </button>
          </div>
        </div>

        {/* Backend Config */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Backend Configuration</label>
          <div className="space-y-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
            {formData.backendConfig.map((item, idx) => (
              <div key={idx} className="flex items-start space-x-2">
                <input
                  type="text"
                  value={item.label}
                  onChange={(e) => handleBackendConfigChange(idx, 'label', e.target.value)}
                  placeholder="Label"
                  className="w-1/3 bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <input
                  type="text"
                  value={item.value}
                  onChange={(e) => handleBackendConfigChange(idx, 'value', e.target.value)}
                  placeholder="Value / Description"
                  className="flex-1 bg-white text-slate-900 border border-slate-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <button onClick={() => removeBackendConfig(idx)} className="p-2 text-red-400 hover:text-red-600">
                  <TrashIcon className="w-4 h-4" />
                </button>
              </div>
            ))}
            <button onClick={addBackendConfig} className="flex items-center text-blue-600 text-sm font-semibold mt-2 hover:underline">
              <PlusIcon className="w-4 h-4 mr-1" /> Add Config Item
            </button>
          </div>
        </div>

        {/* Related Systems */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">Related Systems</label>
          <div className="flex flex-wrap gap-2">
            {Object.values(SYSTEM_DOCS).map((sys) => {
              const isSelected = (formData.relatedSystems || []).includes(sys.id);
              return (
                <button
                  key={sys.id}
                  onClick={() => handleSystemToggle(sys.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                    isSelected
                      ? 'bg-blue-100 border-blue-300 text-blue-700'
                      : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {sys.title.split('(')[0]} {isSelected && '✓'}
                </button>
              );
            })}
          </div>
        </div>
        
        {/* Key Flows - Simplified Editor (Just JSON for now or Text Area? Let's do a simple disclaimer) */}
        <div className="bg-yellow-50 p-3 rounded border border-yellow-200 text-xs text-yellow-700">
            <p><strong>Note:</strong> Editing "Key Flows" is not supported in this quick editor version. Please modify the code directly for complex flow steps.</p>
        </div>

      </div>
    </div>
  );
};

export default DocEditor;
