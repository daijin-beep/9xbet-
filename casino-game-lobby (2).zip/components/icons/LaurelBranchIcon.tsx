import React from 'react';
import { SVGIconProps } from '../../types';

export const LaurelBranchIcon: React.FC<SVGIconProps> = (props) => (
  <svg width="42" height="104" viewBox="0 0 42 104" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M41 1C30.3333 19.8333 11.6 48.6 1 52C11.6 55.4 30.3333 83.1667 41 103" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M21 26C27.6667 27.6667 36.4 31.4 41 34" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M21 78C27.6667 76.3333 36.4 72.6 41 70" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M12 40C19 43 28.3333 47.3333 32 52" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M12 64C19 61 28.3333 56.6667 32 52" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M1 52C4.33333 52 8.6 52 10 52" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M25 15C30.3333 17.6667 39.4 24.4 41 26" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
    <path d="M25 89C30.3333 86.3333 39.4 79.6 41 78" stroke="white" strokeOpacity="0.2" strokeWidth="2"/>
  </svg>
);
