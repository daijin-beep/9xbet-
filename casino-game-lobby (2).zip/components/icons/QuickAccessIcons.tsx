
import React from 'react';
import { SVGIconProps } from '../../types';

export const GiftBoxIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 11.25v8.25a1.5 1.5 0 01-1.5 1.5H7.5a1.5 1.5 0 01-1.5-1.5v-8.25M12 4.875A3.375 3.375 0 006.375 8.25v1.875c0 .451.18.882.501 1.198l4.501 4.002a1.875 1.875 0 002.246 0l4.501-4.002c.32-.316.501-.747.501-1.198V8.25A3.375 3.375 0 0012 4.875z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.875v.01M12 12.375v.01M12 19.875v.01" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 12.375h9" />
  </svg>
);

export const PiggyBankIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 8.25h13.5M5.25 8.25a2.25 2.25 0 01-2.25-2.25v0A2.25 2.25 0 015.25 3.75h13.5a2.25 2.25 0 012.25 2.25v0a2.25 2.25 0 01-2.25 2.25m-10.5-2.25h.008v.008H7.5V6m0 2.25H6.375m4.125 0h.008v.008h-.008V8.25m0 0H11.25m2.625 0h.008v.008H13.5V8.25m0 0H12.375m0 0h-.008V8.25M15 12a3 3 0 11-6 0 3 3 0 016 0zm0 0v6.75m-6-6.75v6.75m0-6.75H9m6 0H15m0 0H9m6 0a2.25 2.25 0 00-2.25-2.25H11.25a2.25 2.25 0 00-2.25 2.25M15 12a2.25 2.25 0 012.25 2.25v0a2.25 2.25 0 01-2.25 2.25H9a2.25 2.25 0 01-2.25-2.25v0A2.25 2.25 0 019 12m6 0v2.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 12a2.25 2.25 0 012.25 2.25v4.5a2.25 2.25 0 01-2.25 2.25H6.75a2.25 2.25 0 01-2.25-2.25V14.25a2.25 2.25 0 012.25-2.25" />
  </svg>
);

export const CrownIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.324h5.372c.516 0 .73.67.338.978l-4.345 3.155a.562.562 0 00-.188.518l1.64 5.044a.562.562 0 01-.824.622l-4.353-3.161a.563.563 0 00-.652 0L5.937 19.25a.562.562 0 01-.824-.622l1.64-5.044a.562.562 0 00-.188-.518L2.219 9.91a.562.562 0 01.339-.978h5.372a.563.563 0 00.475-.324L11.48 3.5z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 20.25h15" />
  </svg>
);

export const DocumentTextIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 6h4.5M9.75 9h4.5M9.75 12h2.25" />
  </svg>
);

export const DollarBagIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 11.219 12.768 11 12 11c-.768 0-1.536.219-2.121.782l-.879.659M7.5 10.5h.008v.008H7.5v-.008zm0 3h.008v.008H7.5v-.008zm7.5-3h.008v.008H15v-.008zm0 3h.008v.008H15v-.008z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a6 6 0 006.75 0c1.002-.701 1.689-1.29 2.25-2.062a9.72 9.72 0 002.25-4.188V6.75A2.25 2.25 0 0011.25 4.5h-1.5a2.25 2.25 0 00-2.25 2.25v6.75" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.928 6.082A6.002 6.002 0 0112 4.5c2.393 0 4.534.863 6.072 2.282M1.5 10.5a6.002 6.002 0 003.428 5.518" />
     <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 18.75a6 6 0 01-6.75 0c-1.002-.701-1.689-1.29-2.25-2.062a9.72 9.72 0 01-2.25-4.188V6.75A2.25 2.25 0 0112.75 4.5h1.5a2.25 2.25 0 012.25 2.25v6.75" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.072 6.082A6.002 6.002 0 0012 4.5c-2.393 0-4.534.863-6.072 2.282M22.5 10.5a6.002 6.002 0 01-3.428 5.518" />
  </svg>
);

export const SquaresIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25A2.25 2.25 0 0113.5 8.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" />
  </svg>
);

    