

import React from 'react';
import { SVGIconProps } from '../../types';

// FIX: Changed to correctly re-export FireIcon from GenericIcons.
export { FireIcon } from './GenericIcons';

export const DiceIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-2.25-1.313M21 7.5v6M21 7.5c0-1.243-.894-2.313-2.072-2.612M3 7.5l2.25-1.313M3 7.5v6M3 7.5c0-1.243.894-2.313 2.072-2.612M3 13.5c0 1.243.894 2.313 2.072 2.612M21 13.5c0 1.243-.894 2.313-2.072 2.612M12 3.75c-3.452 0-6.303 2.193-7.166 5.25M12 3.75c3.452 0 6.303 2.193 7.166 5.25M12 20.25c-3.452 0-6.303-2.193-7.166-5.25M12 20.25c3.452 0 6.303-2.193 7.166-5.25M7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0z" />
    <circle cx="12" cy="12" r="1.5" fill="currentColor" />
    <circle cx="9" cy="9.5" r="1" fill="currentColor" />
    <circle cx="15" cy="9.5" r="1" fill="currentColor" />
    <circle cx="9" cy="14.5" r="1" fill="currentColor" />
    <circle cx="15" cy="14.5" r="1" fill="currentColor" />
  </svg>
);

export const CubeIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5l-9-5.25L3 7.5m18 0l-9 5.25m9-5.25v9l-9 5.25M3 7.5l9 5.25M3 7.5v9l9 5.25m0-9v9" />
  </svg>
);

export const SlotMachineIcon: React.FC<SVGIconProps> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 3.75L9 9m-5.25 5.25v3.75m0-3.75h3.75M9 9l1.5 1.5M3.75 18.75v-3.75m0 3.75h3.75m-3.75 0L9 15m10.5-5.25v-3.75m0 3.75h-3.75M15 9l-1.5 1.5M20.25 3.75v4.5m0-4.5h-4.5m4.5 0L15 9m5.25 5.25v3.75m0-3.75h-3.75m3.75 0L15 15M9 15l1.5 1.5M15 15l-1.5 1.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 15.75H14.25M9.75 12H14.25M9.75 8.25H14.25" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 21.75h15A2.25 2.25 0 0021.75 19.5V4.5A2.25 2.25 0 0019.5 2.25h-15A2.25 2.25 0 002.25 4.5v15A2.25 2.25 0 004.5 21.75z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 7.5h1.5M16.5 12h1.5M16.5 16.5h1.5" />
  </svg>
);
