import React from 'react';
import { SVGIconProps } from '../../types';

export const PromoPercentIcon: React.FC<SVGIconProps> = (props) => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M15.0001 9.3C15.0001 8.58 14.4201 8 13.7001 8C12.9801 8 12.4001 8.58 12.4001 9.3C12.4001 10.02 12.9801 10.6 13.7001 10.6C14.4201 10.6 15.0001 10.02 15.0001 9.3Z" fill="white"/>
    <path d="M10.3 14C10.3 14.72 9.72 15.3 9 15.3C8.28 15.3 7.7 14.72 7.7 14C7.7 13.28 8.28 12.7 9 12.7C9.72 12.7 10.3 13.28 10.3 14Z" fill="white"/>
    <path d="M15.41 15.86L8.14 8.59001" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);