import React, { useState } from 'react';
import SettingsSection from './SettingsSection';
import SettingsItem from './SettingsItem';
import { ShieldCheckIcon, LockClosedIcon, EnvelopeIcon, DevicePhoneMobileIcon, QrCodeIcon } from '../icons/GenericIcons';

interface SettingsSecurityProps {
  onChangePasswordClick: () => void;
  onBindPhoneClick: () => void;
  onBindEmailClick: () => void;
}

const SettingsSecurity: React.FC<SettingsSecurityProps> = ({
  onChangePasswordClick,
  onBindPhoneClick,
  onBindEmailClick,
}) => {
    // Mock state for security features
    const [is2faEnabled, setIs2faEnabled] = useState(true);
    const [isPinSet, setIsPinSet] = useState(false);

    return (
        <SettingsSection
            title="账号与安全"
            description="管理您的登录凭证和安全设置。"
            Icon={ShieldCheckIcon}
        >
            <div className="space-y-2">
                <SettingsItem
                    label="登录密码"
                    value="定期更换以提高安全性"
                    Icon={LockClosedIcon}
                    actionText="更换"
                    onClick={onChangePasswordClick}
                />
                <SettingsItem
                    label="绑定手机"
                    value="+7 •••• •••• 12-34"
                    Icon={DevicePhoneMobileIcon}
                    actionText="更换"
                    onClick={onBindPhoneClick}
                />
                <SettingsItem
                    label="绑定邮箱"
                    value="casino••••@gmail.com"
                    Icon={EnvelopeIcon}
                    actionText="更换"
                    onClick={onBindEmailClick}
                />
                 <SettingsItem
                    label="二步验证 (2FA)"
                    value={is2faEnabled ? "已开启 (Authenticator App)" : "未开启"}
                    Icon={QrCodeIcon}
                    actionText={is2faEnabled ? "管理" : "开启"}
                    onClick={() => alert('Open 2FA management')}
                    status={is2faEnabled ? 'enabled' : 'disabled'}
                />
                 <SettingsItem
                    label="二级密码 (资金密码)"
                    value={isPinSet ? "已设置" : "未设置"}
                    Icon={LockClosedIcon}
                    actionText={isPinSet ? "修改" : "设置"}
                    onClick={() => alert('Open PIN management')}
                     status={isPinSet ? 'enabled' : 'disabled'}
                />
            </div>
        </SettingsSection>
    );
};

export default SettingsSecurity;