import React from 'react';
import SettingsSection from './SettingsSection';
import { DevicePhoneMobileIcon, ArrowRightOnRectangleIcon } from '../icons/GenericIcons';
import { MOCK_SESSIONS } from '../../constants';
import { Session } from '../../types';

const SessionItem: React.FC<{ session: Session }> = ({ session }) => (
    <div className="flex items-center p-3 bg-slate-700/50 rounded-md">
        <DevicePhoneMobileIcon className="w-8 h-8 text-gray-400 mr-4 flex-shrink-0" />
        <div className="flex-grow">
            <p className="font-semibold text-white">{session.device}</p>
            <p className="text-xs text-gray-400">{session.location} ({session.ipAddress})</p>
            {session.isCurrent ? (
                 <p className="text-xs font-bold text-green-400 mt-1">当前设备</p>
            ) : (
                 <p className="text-xs text-gray-500 mt-1">上次活跃: {session.lastActive}</p>
            )}
        </div>
        {!session.isCurrent && (
            <button 
                className="ml-4 p-2 text-gray-400 hover:text-red-500 hover:bg-slate-600 rounded-full"
                aria-label={`Log out from ${session.device}`}
                onClick={() => alert(`Logging out from ${session.id}`)}
            >
                <ArrowRightOnRectangleIcon className="w-5 h-5" />
            </button>
        )}
    </div>
);


const SettingsSessions: React.FC = () => {
    return (
        <SettingsSection
            title="设备与会话"
            description="管理您已登录的设备。"
            Icon={DevicePhoneMobileIcon}
        >
            <div className="space-y-3">
                {MOCK_SESSIONS.map(session => (
                    <SessionItem key={session.id} session={session} />
                ))}
            </div>
            <button className="w-full mt-4 bg-red-600/20 hover:bg-red-500/30 text-red-400 font-semibold py-2.5 rounded-md text-sm transition-colors border border-red-500/30">
                登出所有其他设备
            </button>
        </SettingsSection>
    );
};

export default SettingsSessions;