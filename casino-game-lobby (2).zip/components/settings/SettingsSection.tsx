import React from 'react';
import { SVGIconProps } from '../../types';

interface SettingsSectionProps {
  title: string;
  description?: string;
  Icon: React.FC<SVGIconProps>;
  children: React.ReactNode;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({ title, description, Icon, children }) => {
  return (
    <section className="bg-slate-800 rounded-lg shadow-md border border-slate-700">
      <div className="p-4 border-b border-slate-700">
        <div className="flex items-center">
          <Icon className="w-6 h-6 text-blue-400 mr-3" />
          <div>
            <h2 className="text-lg font-bold text-white">{title}</h2>
            {description && <p className="text-xs text-gray-400">{description}</p>}
          </div>
        </div>
      </div>
      <div className="p-4">
        {children}
      </div>
    </section>
  );
};

export default SettingsSection;