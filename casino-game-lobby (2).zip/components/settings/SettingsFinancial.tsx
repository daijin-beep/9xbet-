import React, { useState } from 'react';
import SettingsSection from './SettingsSection';
import SettingsItem from './SettingsItem';
import { BanknotesIcon, ListBulletIcon, ShieldCheckIcon, CreditCardIcon } from '../icons/GenericIcons';

interface SettingsFinancialProps {
    onManageMethodsClick: () => void;
}

const SettingsFinancial: React.FC<SettingsFinancialProps> = ({ onManageMethodsClick }) => {
    const [isWhitelistEnabled, setIsWhitelistEnabled] = useState(false);

    return (
        <SettingsSection
            title="资金安全"
            description="保护您的资金和交易安全。"
            Icon={BanknotesIcon}
        >
            <div className="space-y-2">
                 <SettingsItem
                    label="提现方式"
                    value="管理您的提现方式"
                    Icon={CreditCardIcon}
                    actionText="管理"
                    onClick={onManageMethodsClick}
                />
                <SettingsItem
                    label="提现地址白名单"
                    value={isWhitelistEnabled ? "已开启" : "未开启，提现无需验证地址"}
                    Icon={ListBulletIcon}
                    actionText={isWhitelistEnabled ? "管理" : "开启"}
                    onClick={() => alert('Open whitelist management')}
                    status={isWhitelistEnabled ? 'enabled' : 'disabled'}
                />
                 <SettingsItem
                    label="敏感操作保护"
                    value="资金密码 + 2FA"
                    Icon={ShieldCheckIcon}
                    actionText="修改"
                    onClick={() => alert('Open sensitive operation settings')}
                />
            </div>
        </SettingsSection>
    );
};

export default SettingsFinancial;
