import React, { useState, useEffect } from 'react';
import { CloseIcon, ArrowLeftIcon } from '../../icons/GenericIcons';

interface BindPhoneModalProps {
  onClose: () => void;
}

const BindPhoneModal: React.FC<BindPhoneModalProps> = ({ onClose }) => {
  const [step, setStep] = useState(1); // 1: Enter password, 2: Enter phone, 3: Enter code
  const [loginPassword, setLoginPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [timer, setTimer] = useState(0);
  const [error, setError] = useState('');

  useEffect(() => {
    // FIX: Use ReturnType<typeof setInterval> for cross-environment compatibility.
    let interval: ReturnType<typeof setInterval>;
    if (timer > 0) {
      interval = setInterval(() => {
        setTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timer]);

  const handlePasswordSubmit = () => {
    if (loginPassword.length < 6) { // Mock validation
      setError('Invalid password.');
      return;
    }
    setError('');
    setStep(2);
  };

  const handleSendCode = () => {
    if (phone.length < 10) { // Simple validation
      setError('Please enter a valid phone number.');
      return;
    }
    setError('');
    setTimer(60);
    setStep(3);
  };

  const handleConfirm = () => {
    if (code !== '123456') { // Mock verification
      setError('Invalid verification code.');
      return;
    }
    setError('');
    alert('Phone bound successfully!');
    onClose();
  };

  const handleBack = () => {
      if (step === 2) {
          setStep(1);
          setPhone('');
      } else if (step === 3) {
          setStep(2);
          setCode('');
      }
      setError('');
  }
  
  const commonInputClasses = "w-full bg-slate-700 text-gray-200 border border-slate-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500";

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-[100]">
      <div className="bg-slate-800 w-full max-w-md p-6 rounded-lg shadow-xl relative text-gray-200">
        <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6" /></button>
        {step > 1 && <button onClick={handleBack} className="absolute top-3 left-3 text-gray-400 hover:text-white"><ArrowLeftIcon className="w-6 h-6" /></button>}
        
        <h2 className="text-xl font-semibold mb-6 text-center text-white">Bind Phone Number</h2>
        
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-1 block">Login Password</label>
              <input 
                type="password" 
                value={loginPassword} 
                onChange={e => setLoginPassword(e.target.value)} 
                className={commonInputClasses} 
                placeholder="Enter your login password for verification" 
                required 
              />
            </div>
            {error && <p className="text-sm text-red-400 text-center">{error}</p>}
            <button onClick={handlePasswordSubmit} className="w-full bg-blue-600 hover:bg-blue-700 font-semibold py-2.5 rounded-md">Next</button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-1 block">New Phone Number</label>
              <div className="flex">
                  <span className="inline-flex items-center px-3 text-sm text-gray-300 bg-slate-700 border border-r-0 border-slate-600 rounded-l-md">+7</span>
                  <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className={`${commonInputClasses} rounded-l-none`} placeholder="912 345-67-89" />
              </div>
            </div>
            {error && <p className="text-sm text-red-400 text-center">{error}</p>}
            <button onClick={handleSendCode} className="w-full bg-blue-600 hover:bg-blue-700 font-semibold py-2.5 rounded-md">Send Code</button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
             <p className="text-sm text-center text-gray-400">Код отправлен на +7 •••• •••• {phone.slice(-4)}. Повторная отправка через 00:{String(timer).padStart(2, '0')}.</p>
            <div>
              <label className="text-sm font-medium text-gray-300 mb-1 block">Verification Code</label>
              <div className="flex items-center space-x-2">
                  <input type="text" value={code} onChange={e => setCode(e.target.value)} maxLength={6} className={commonInputClasses} />
                  <button onClick={() => setTimer(60)} disabled={timer > 0} className="text-sm text-blue-400 disabled:text-gray-500 disabled:cursor-not-allowed whitespace-nowrap">
                      {timer > 0 ? `Resend (${timer}s)` : 'Resend'}
                  </button>
              </div>
            </div>
            {error && <p className="text-sm text-red-400 text-center">{error}</p>}
            <button onClick={handleConfirm} className="w-full bg-blue-600 hover:bg-blue-700 font-semibold py-2.5 rounded-md">Confirm</button>
          </div>
        )}
      </div>
    </div>
  );
};
export default BindPhoneModal;
