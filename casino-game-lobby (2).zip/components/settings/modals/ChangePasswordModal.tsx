import React, { useState, useMemo } from 'react';
import { CloseIcon, CheckboxIcon, CheckboxCheckedIcon } from '../../icons/GenericIcons';

interface ChangePasswordModalProps {
  onClose: () => void;
}

const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ onClose }) => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [logoutOthers, setLogoutOthers] = useState(false);
  const [error, setError] = useState('');

  const passwordStrength = useMemo(() => {
    let strength = 0;
    if (newPassword.length >= 8) strength++;
    if (newPassword.match(/[a-z]/)) strength++;
    if (newPassword.match(/[A-Z]/)) strength++;
    if (newPassword.match(/[0-9]/)) strength++;
    if (newPassword.match(/[^a-zA-Z0-9]/)) strength++;
    return strength;
  }, [newPassword]);

  const strengthText = ['Very Weak', 'Weak', 'Medium', 'Strong', 'Very Strong'];
  const strengthColor = ['bg-red-500', 'bg-orange-500', 'bg-yellow-500', 'bg-lime-500', 'bg-green-500'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match.');
      return;
    }
    if (passwordStrength < 3) {
      setError('New password is too weak.');
      return;
    }
    setError('');
    // Handle successful password change
    alert('Password changed successfully!');
    onClose();
  };
  
  const commonInputClasses = "w-full bg-slate-700 text-gray-200 border border-slate-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500";

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-[100]">
      <div className="bg-slate-800 w-full max-w-md p-6 rounded-lg shadow-xl relative text-gray-200">
        <button onClick={onClose} className="absolute top-3 right-3 text-gray-400 hover:text-white"><CloseIcon className="w-6 h-6" /></button>
        <h2 className="text-xl font-semibold mb-6 text-center text-white">Reset Login Password</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-300 mb-1 block">Current Password</label>
            <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className={commonInputClasses} required />
          </div>
          <div>
            <label className="text-sm font-medium text-gray-300 mb-1 block">New Password</label>
            <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} className={commonInputClasses} required />
            <div className="flex space-x-1 mt-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className={`h-1 flex-1 rounded-full ${i < passwordStrength ? strengthColor[passwordStrength - 1] : 'bg-slate-600'}`}></div>
              ))}
            </div>
            {newPassword.length > 0 && <p className="text-xs text-gray-400 mt-1">Strength: {strengthText[passwordStrength - 1]}</p>}
          </div>
          <div>
            <label className="text-sm font-medium text-gray-300 mb-1 block">Confirm New Password</label>
            <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className={commonInputClasses} required />
          </div>
          
          <label htmlFor="logoutOthers" className="flex items-center space-x-2 cursor-pointer text-sm text-gray-300">
              <input type="checkbox" id="logoutOthers" checked={logoutOthers} onChange={e => setLogoutOthers(e.target.checked)} className="hidden" />
              {logoutOthers ? <CheckboxCheckedIcon className="w-5 h-5 text-green-500" /> : <CheckboxIcon className="w-5 h-5 text-gray-400 border-gray-500" />}
              <span>同時登出其他設備</span>
          </label>
          
          {error && <p className="text-sm text-red-400 text-center">{error}</p>}

          <div className="flex space-x-3 pt-2">
            <button type="button" onClick={onClose} className="flex-1 bg-slate-600 hover:bg-slate-500 font-semibold py-2.5 rounded-md">Cancel</button>
            <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 font-semibold py-2.5 rounded-md">Confirm</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChangePasswordModal;
