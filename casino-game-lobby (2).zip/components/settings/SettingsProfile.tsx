import React, { useState, useEffect } from 'react';
import SettingsSection from './SettingsSection';
import { UserCircleIcon, ChevronDownIcon } from '../icons/GenericIcons';

const SettingsProfile: React.FC = () => {
  const [formData, setFormData] = useState({
    nickname: 'CasinoKing',
    country: 'RU',
    language: 'EN',
    currency: 'RUB'
  });
  const [isDirty, setIsDirty] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    setIsDirty(false); 
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setIsDirty(true);
  };

  const handleSave = () => {
    console.log('Saving data:', formData);
    setIsDirty(false);
    setToastMessage('资料已更新');
    setTimeout(() => setToastMessage(null), 3000);
  };

  return (
    <SettingsSection
      title="个人资料"
      description="管理您的个人信息和偏好设置。"
      Icon={UserCircleIcon}
    >
      <div className="space-y-4">
        {/* Nickname */}
        <div>
          <label htmlFor="nickname" className="block text-sm font-medium text-gray-300 mb-1">昵称</label>
          <input
            type="text"
            id="nickname"
            name="nickname"
            value={formData.nickname}
            onChange={handleChange}
            className="w-full bg-slate-700 text-gray-200 border border-slate-600 rounded-md py-2 px-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
           <p className="text-xs text-gray-500 mt-1">2–16 个字符, 允许字母/数字/下划线/俄文字母</p>
        </div>
        
        {/* Country */}
        <div className="relative">
             <label htmlFor="country" className="block text-sm font-medium text-gray-300 mb-1">居住国家</label>
            <select name="country" id="country" value={formData.country} onChange={handleChange} className="w-full bg-slate-700 text-gray-200 border border-slate-600 rounded-md py-2 px-3 appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="RU">Russia</option>
                <option value="US">United States</option>
                <option value="CN">China</option>
            </select>
            <ChevronDownIcon className="w-5 h-5 text-gray-400 absolute right-3 top-9 pointer-events-none" />
        </div>
        
        {/* Language */}
         <div className="relative">
             <label htmlFor="language" className="block text-sm font-medium text-gray-300 mb-1">语言</label>
            <select name="language" id="language" value={formData.language} onChange={handleChange} className="w-full bg-slate-700 text-gray-200 border border-slate-600 rounded-md py-2 px-3 appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="EN">English</option>
                <option value="RU">Русский</option>
                <option value="ZH">中文</option>
            </select>
            <ChevronDownIcon className="w-5 h-5 text-gray-400 absolute right-3 top-9 pointer-events-none" />
        </div>

        {/* Currency */}
        <div className="relative">
            <label htmlFor="currency" className="block text-sm font-medium text-gray-300 mb-1">首选币种</label>
            <select name="currency" id="currency" value={formData.currency} onChange={handleChange} className="w-full bg-slate-700 text-gray-200 border border-slate-600 rounded-md py-2 px-3 appearance-none focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="RUB">RUB</option>
                <option value="USDT">USDT</option>
            </select>
            <ChevronDownIcon className="w-5 h-5 text-gray-400 absolute right-3 top-9 pointer-events-none" />
        </div>
        
        {/* Save Button */}
        <div className="pt-2">
            <button
                onClick={handleSave}
                disabled={!isDirty}
                className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg shadow-lg transition-colors enabled:hover:bg-blue-700 disabled:bg-slate-700 disabled:text-gray-500 disabled:cursor-not-allowed"
            >
                保存
            </button>
        </div>
      </div>
       {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded-lg shadow-lg">
          {toastMessage}
        </div>
      )}
    </SettingsSection>
  );
};

export default SettingsProfile;