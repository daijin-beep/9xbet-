import React from 'react';
import { SVGIconProps } from '../../types';
import { ChevronRightIcon, ShieldCheckIcon, ExclamationTriangleIcon } from '../icons/GenericIcons';

interface SettingsItemProps {
  label: string;
  value: string;
  Icon: React.FC<SVGIconProps>;
  actionText: string;
  onClick: () => void;
  status?: 'enabled' | 'disabled';
}

const SettingsItem: React.FC<SettingsItemProps> = ({ label, value, Icon, actionText, onClick, status }) => {
  const statusIndicator = {
    enabled: <ShieldCheckIcon className="w-4 h-4 text-green-400" />,
    disabled: <ExclamationTriangleIcon className="w-4 h-4 text-yellow-400" />,
  };

  return (
    <button 
      onClick={onClick}
      className="w-full flex items-center p-3 text-left bg-slate-700/50 hover:bg-slate-700 rounded-md transition-colors"
    >
      <Icon className="w-6 h-6 text-gray-300 mr-4 flex-shrink-0" />
      <div className="flex-grow">
        <p className="font-semibold text-white">{label}</p>
        <p className="text-xs text-gray-400 flex items-center space-x-1">
          {status && statusIndicator[status]}
          <span>{value}</span>
        </p>
      </div>
      <div className="flex items-center ml-4">
        <span className="text-sm text-gray-300 mr-2">{actionText}</span>
        <ChevronRightIcon className="w-5 h-5 text-gray-500" />
      </div>
    </button>
  );
};

export default SettingsItem;