
import React, { useState, useEffect } from 'react';
import { CloseIcon, CheckboxIcon, CheckboxCheckedIcon } from '../icons/GenericIcons';
import { User, UserRole } from '../../types';

interface GlobalConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: {
    isLoggedIn: boolean;
    user: User;
  };
  onUpdate: (newConfig: { isLoggedIn: boolean; user: User }) => void;
}

export const GlobalConfigModal: React.FC<GlobalConfigModalProps> = ({ isOpen, onClose, config, onUpdate }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(config.isLoggedIn);
  const [user, setUser] = useState<User>(config.user);

  // Sync internal state with props when modal opens
  useEffect(() => {
    if (isOpen) {
      setIsLoggedIn(config.isLoggedIn);
      setUser(config.user);
    }
  }, [isOpen, config]);

  const handleRoleChange = (role: UserRole) => {
    setUser(prev => {
      const roles = prev.roles.includes(role)
        ? prev.roles.filter(r => r !== role)
        : [...prev.roles, role];
      return { ...prev, roles };
    });
  };

  const handleSave = () => {
    onUpdate({ isLoggedIn, user });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[200] backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
          <h3 className="text-lg font-bold text-gray-800">开发者全局配置 (Dev Global Config)</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><CloseIcon className="w-6 h-6"/></button>
        </div>
        
        <div className="p-6 overflow-y-auto space-y-6 no-scrollbar">
          {/* Auth Status */}
          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-xl border border-blue-100">
            <div>
                <span className="font-bold text-blue-800">用户登录状态模拟</span>
                <p className="text-[10px] text-blue-600">切换未登录/登录状态，测试权限拦截</p>
            </div>
            <button 
              onClick={() => setIsLoggedIn(!isLoggedIn)}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${isLoggedIn ? 'bg-green-500' : 'bg-gray-300'}`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isLoggedIn ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>

          <hr className="border-gray-100" />

          {/* User Details */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-gray-500 uppercase tracking-wider">用户基础资料 (User Profile)</h4>
            
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">用户昵称 (Nickname)</label>
                    <input 
                        type="text" 
                        value={user.nickname}
                        onChange={e => setUser({...user, nickname: e.target.value})}
                        className="w-full border border-gray-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                </div>
                <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">VIP 等级 (1-10)</label>
                    <input 
                        type="number" 
                        min="1" max="10"
                        value={user.vipLevel}
                        onChange={e => setUser({...user, vipLevel: Number(e.target.value)})}
                        className="w-full border border-gray-300 rounded-md p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                </div>
            </div>

            <div>
                <label className="block text-[11px] font-bold text-gray-500 mb-1">头像链接 (Avatar URL)</label>
                <input 
                    type="text" 
                    value={user.avatarUrl}
                    onChange={e => setUser({...user, avatarUrl: e.target.value})}
                    className="w-full border border-gray-300 rounded-md p-2 text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                />
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">主账户余额 (Main Balance)</label>
                    <input 
                        type="number" 
                        value={user.balance}
                        onChange={e => setUser({...user, balance: Number(e.target.value)})}
                        className="w-full border border-gray-300 rounded-md p-2 text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                </div>
                <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">红利余额 (Bonus Balance)</label>
                    <input 
                        type="number" 
                        value={user.bonusBalance}
                        onChange={e => setUser({...user, bonusBalance: Number(e.target.value)})}
                        className="w-full border border-gray-300 rounded-md p-2 text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-[11px] font-bold text-gray-500 mb-1">锁定金额 (Locked RUB)</label>
                    <input 
                        type="number" 
                        value={user.lockedBalance}
                        onChange={e => setUser({...user, lockedBalance: Number(e.target.value)})}
                        className="w-full border border-gray-300 rounded-md p-2 text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="用于测试提现拦截"
                    />
                </div>
                <div className="flex items-center justify-between pt-4">
                    <span className="text-[11px] font-bold text-gray-500">是否充值用户?</span>
                    <button 
                        onClick={() => setUser({...user, isPaidUser: !user.isPaidUser})}
                        className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors ${user.isPaidUser ? 'bg-blue-600' : 'bg-gray-300'}`}
                    >
                        <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${user.isPaidUser ? 'translate-x-6' : 'translate-x-1'}`} />
                    </button>
                </div>
            </div>
          </div>

          <hr className="border-gray-100" />

          {/* Roles */}
          <div>
            <h4 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-3">身份角色模拟 (User Roles)</h4>
            <div className="grid grid-cols-2 gap-2">
                {(['normal', 'kol', 'agent_all', 'distributor'] as UserRole[]).map(role => (
                    <label key={role} className="flex items-center space-x-3 cursor-pointer bg-gray-50 p-3 rounded-xl border border-gray-200 hover:bg-gray-100 transition-colors">
                        <div onClick={(e) => { e.preventDefault(); handleRoleChange(role); }}>
                            {user.roles.includes(role) 
                                ? <CheckboxCheckedIcon className="w-5 h-5 text-blue-600" /> 
                                : <CheckboxIcon className="w-5 h-5 text-gray-400" />
                            }
                        </div>
                        <div className="flex flex-col">
                            <span className="text-sm font-bold text-gray-700 capitalize">{role.replace('_', ' ')}</span>
                            <span className="text-[9px] text-gray-500">测试 {role} 专属功能</span>
                        </div>
                    </label>
                ))}
            </div>
          </div>

        </div>

        <div className="p-4 border-t border-gray-200 bg-gray-50 flex justify-end space-x-3">
            <button onClick={onClose} className="px-5 py-2 text-gray-600 hover:bg-gray-200 rounded-xl font-bold transition-all">取消</button>
            <button onClick={handleSave} className="px-8 py-2 bg-blue-600 text-white rounded-xl font-black hover:bg-blue-700 shadow-lg shadow-blue-900/20 active:scale-95 transition-all">应用并更新状态</button>
        </div>
      </div>
    </div>
  );
};

interface PageConfigModalProps {
    isOpen: boolean;
    onClose: () => void;
    activePage: string;
    config: Record<string, any>;
    onUpdate: (key: string, value: any) => void;
}

export const PageConfigModal: React.FC<PageConfigModalProps> = ({ isOpen, onClose, activePage, config, onUpdate }) => {
    if (!isOpen) return null;

    const renderFields = () => {
        switch (activePage) {
            case 'home':
                return (
                    <div className="flex items-center justify-between p-4 bg-purple-50 rounded-xl border border-purple-100">
                        <div>
                            <span className="text-purple-800 font-bold">显示 App 下载横幅</span>
                            <p className="text-[10px] text-purple-600">强制在大厅顶部显示引导条</p>
                        </div>
                        <button 
                            onClick={() => onUpdate('showDownloadBanner', !config.showDownloadBanner)}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${config.showDownloadBanner ? 'bg-purple-600' : 'bg-gray-300'}`}
                        >
                            <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${config.showDownloadBanner ? 'translate-x-6' : 'translate-x-1'}`} />
                        </button>
                    </div>
                );
            case 'kolOverview':
                return (
                    <div className="space-y-4">
                        <label className="block text-sm font-bold text-gray-700 mb-2">当前代理等级 (Agent Level)</label>
                        <select 
                            value={config.agentLevel || 'Gold'} 
                            onChange={(e) => onUpdate('agentLevel', e.target.value)}
                            className="w-full border border-gray-300 rounded-xl p-3 bg-white focus:ring-2 focus:ring-purple-500 outline-none shadow-sm"
                        >
                            <option value="Bronze">Bronze (20%)</option>
                            <option value="Silver">Silver (25%)</option>
                            <option value="Gold">Gold (35%)</option>
                            <option value="Platinum">Platinum (45%)</option>
                        </select>
                    </div>
                );
            default:
                return (
                    <div className="text-center py-10 space-y-3">
                        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto text-gray-400">
                             <CloseIcon className="w-8 h-8" />
                        </div>
                        <p className="text-gray-500 font-bold uppercase tracking-widest text-xs">当前页面 <strong>{activePage}</strong> 无特殊配置项</p>
                    </div>
                );
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[200] backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
                <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <div>
                        <h3 className="text-lg font-black text-gray-800 tracking-tight">页面动态配置</h3>
                        <p className="text-[10px] text-gray-400 font-bold uppercase">{activePage} Dynamic Context</p>
                    </div>
                    <button onClick={onClose} className="p-2 text-gray-400 hover:text-gray-800 hover:bg-gray-100 rounded-full transition-colors"><CloseIcon className="w-6 h-6"/></button>
                </div>
                <div className="p-6">
                    {renderFields()}
                </div>
                <div className="p-4 border-t border-gray-100 bg-gray-50/50 flex justify-end">
                    <button onClick={onClose} className="px-8 py-2 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-900 shadow-md active:scale-95 transition-all">确定</button>
                </div>
            </div>
        </div>
    );
};
